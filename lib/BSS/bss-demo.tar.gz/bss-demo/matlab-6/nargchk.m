function msg = nargchk(low,high,number)
%NARGCHK Validate number of input arguments. 
%   MSG = NARGCHK(LOW,HIGH,N) returns an appropriate error message if
%   N is not between low and high. If it is, return empty matrix.
%
%   See also NARGOUTCHK, NARGIN, NARGOUT, INPUTNAME.

%   Copyright 1984-2001 The MathWorks, Inc. 
%   $Revision: 5.11 $  $Date: 2001/04/15 12:00:04 $

msg = [];
if (number < low)
    msg = 'Not enough input arguments.';
elseif (number > high)
    msg = 'Too many input arguments.';
end

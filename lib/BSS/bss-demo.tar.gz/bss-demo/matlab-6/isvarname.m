function t = isvarname(s)
%ISVARNAME True for valid variable name.
%   ISVARNAME(S) is true if S is a valid MATLAB variable name.
%   A valid variable name is a character string of letters, digits and
%   underscores, with length <= 31 and the first character a letter.
%
%   See also ISKEYWORD.

%   Copyright 1984-2001 The MathWorks, Inc. 
%   $Revision: 1.5 $  $Date: 2001/04/15 12:00:07 $

t = ischar(s) & size(s,1) == 1 & length(s) <= 31;
if t
   t = isletter(s(1)) & all(isletter(s) | s == '_' | ('0' <= s & s <= '9'));
   t = t & ~iskeyword(s); 
end
